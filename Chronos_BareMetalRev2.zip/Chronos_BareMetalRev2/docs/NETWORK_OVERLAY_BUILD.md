# Network Core Overlay — Build Instructions

**Medical device.** The network core UART is moved from **P1.00/P1.01** to **P0.19 (TX)** and **P0.21 (RX)** so that **P1.00** and **P1.01** can be used by the application for the switch.

---

## 1. Overlay and Pin Assignments

| Overlay | Location | Purpose |
|--------|----------|---------|
| **Network core (cpunet)** | `boards/nrf5340dk_nrf5340_cpunet.overlay` | UART0 on **P0.19** (TX), **P0.21** (RX); cpunet has uart0 only |
| **Application (cpuapp)** | `app.overlay` | UART0 (NUS) on **P0.23** (TX), **P0.25** (RX); UART1 disabled |

- **Network UART:** P0.19 = TX, P0.21 = RX  
- **App NUS UART:** P0.23 = TX, P0.25 = RX  
- **Switch:** P1.00, P1.01, P1.03, P0.13 (no longer used by UART)

---

## 2. Adding the Network Overlay to the Build

The network overlay must be applied to the **ipc_radio** (cpunet) image. Use one of the following.

### Option A: West build (command line)

Pass the overlay via CMake:

```bash
west build -b nrf5340dk/nrf5340 --sysbuild \
  -- -Dipc_radio_EXTRA_DTC_OVERLAY_FILE=boards/nrf5340dk_nrf5340_cpunet.overlay
```

If you use a separate sysbuild config (e.g. `sysbuild_bt_rpc.conf`):

```bash
west build -b nrf5340dk/nrf5340 --sysbuild -d build \
  --sysbuild-config sysbuild_bt_rpc.conf \
  -- -Dipc_radio_EXTRA_DTC_OVERLAY_FILE=boards/nrf5340dk_nrf5340_cpunet.overlay
```

Paths are relative to the project root.

### Option B: VS Code / nRF Connect for VS Code

1. Open **nRF Connect for VS Code**.
2. **Add the overlay to CMake arguments**:
   - **“Add CMake argument”** (or equivalent), or edit `.vscode-nrf-connect.json` in the build directory.
   - Add:
     ```text
     -Dipc_radio_EXTRA_DTC_OVERLAY_FILE=boards/nrf5340dk_nrf5340_cpunet.overlay
     ```
   - Ensure the path is correct relative to the **project root** (not the build dir).

3. **Rebuild** (e.g. “Build” in the nRF Connect panel).  
   If your setup uses a build config / `cmakeArgs` in the UI, add the same `-D...` there.

### Option C: Sysbuild board overlay layout (if supported)

Some NCS sysbuild setups pick up board-specific overlays from:

```text
sysbuild/ipc_radio/boards/nrf5340dk_nrf5340_cpunet.overlay
```

If your NCS version supports this:

1. Create `sysbuild/ipc_radio/boards/` if it does not exist.
2. Copy `boards/nrf5340dk_nrf5340_cpunet.overlay` to  
   `sysbuild/ipc_radio/boards/nrf5340dk_nrf5340_cpunet.overlay`.

Otherwise, use **Option A** or **B**.

---

## 3. Clean Build After Adding the Overlay

After enabling the overlay (or changing it), do a clean build:

```bash
west build -b nrf5340dk/nrf5340 --sysbuild -d build -p
```

or, with sysbuild config:

```bash
west build -b nrf5340dk/nrf5340 --sysbuild -d build --sysbuild-config sysbuild_bt_rpc.conf -p -- \
  -Dipc_radio_EXTRA_DTC_OVERLAY_FILE=boards/nrf5340dk_nrf5340_cpunet.overlay
```

`-p` prunes the build directory so the new overlay is applied from a clean state.

---

## 4. Wiring

- **NUS (app) UART:** Connect your serial adapter to **P0.23** (TX) and **P0.25** (RX).  
  - MCU **P0.23 (TX)** → adapter **RX**  
  - MCU **P0.25 (RX)** → adapter **TX**

- **Network core UART** (if you use it for debug/logging): **P0.19** (TX), **P0.21** (RX).  
  - Same crossover: MCU TX → adapter RX, MCU RX → adapter TX.

- **Switch:** P1.00, P1.01, P1.03, P0.13 as in your application design.

---

## 5. Verifying the Overlay Is Applied

After building:

1. Check that the **ipc_radio** devicetree was built with the overlay (e.g. inspect `build/ipc_radio/zephyr/zephyr.dts` or build logs for `nrf5340dk_nrf5340_cpunet.overlay`).
2. Confirm **P1.00** and **P1.01** are no longer used by the network UART and that the switch behavior matches expectations.

---

## 6. Summary

| Step | Action |
|------|--------|
| 1 | Ensure `boards/nrf5340dk_nrf5340_cpunet.overlay` exists. |
| 2 | Use **Option A** or **B** (or **C** if supported) to add the overlay to the ipc_radio build. |
| 3 | Clean build (`-p`) then flash. |
| 4 | Wire NUS to **P0.23** / **P0.25** and the switch to **P1.00** / **P1.01** / **P1.03** / **P0.13** as designed. |

If the overlay is not applied, P1.00/P1.01 remain used by the network core and the switch will not have those pins available.

---

## 7. Runtime: MCU pin select (P1.00 / P1.01)

Even with the overlay applied, P1.00 and P1.01 are **owned by the network core** by default. The app reassigns them to the app core via direct **PIN_CNF MCUSEL** writes (in `init_misc_pins()` and **at the start of every timer handler** in `timer.c`) so they stay assigned even if something overwrites them. Ensure you **flash both** the **application** and **network** (ipc_radio) images (e.g. `merged.hex` or both app + ipc_radio hex) so the overlay is active on the network core.

**If P1.00/P1.01 still do not respond:**
1. Confirm the **network overlay is applied** (build with `-Dipc_radio_EXTRA_DTC_OVERLAY_FILE=...` or sysbuild board overlay) and **both images are flashed**.
2. Verify you are building for **nrf5340dk/nrf5340** (app + cpunet).
3. Check that no other software (e.g. Zephyr pinctrl for UART1) is still claiming those pins on the app core.
