# Minimal Power with prj_no_bt: Turning Off Unused Peripherals

**Goal:** Use the no-BLE config to turn off all unused peripherals and features to minimize MCU load, power, and compile time, prioritizing current consumption.

**Answer: Yes, this can be implemented.** The approach is to extend `prj_no_bt.conf` (and optionally use a no-BLE board overlay) so that only the peripherals and features required for RTC-driven stimulation are enabled. Some options can be applied **without code changes**; others need minimal guards in code to avoid linking or runtime use of disabled drivers.

---

## What the No-BLE Path Actually Uses

When `CONFIG_BT=n` (RTC low-power stimulation mode), the application uses:

| Peripheral / feature | Used for | Kconfig / overlay |
|----------------------|----------|--------------------|
| **GPIO**             | DAC CS, switch pins, misc | `CONFIG_GPIO=y` |
| **SPIM1**            | DAC SPI (nrfx)            | `CONFIG_NRFX_SPIM1=y` |
| **TIMER0**           | Biphasic timing (nrfx)    | `CONFIG_NRFX_TIMER0=y` |
| **RTC0**             | Stim period (nrfx)        | `CONFIG_NRFX_RTC0=y` |
| **CLOCK**            | HFCLK, LFCLK (HAL in code)| SoC; no separate Kconfig |
| **Flash**            | Code execution (XIP)      | Kernel needs flash; keep enabled |

**Not used in no-BLE path:** UART (never call `uart_init()`), TIMER1 (only for `MEASURE_TIMER` when BLE), DK LEDs/buttons (never call `configure_gpio()`), logging/console output in the idle loop, settings, BLE stack, RTT, USB.

---

## What Is Already in Place

- **`prj_no_bt.conf`**  
  - BLE off, logging off, reduced debug.  
  - Still enables: UART/SERIAL/CONSOLE (for compatibility with current code), DK_LIBRARY, TIMER1, UARTE0.  
  - **Missing for current RTC stim build:** `CONFIG_NRFX_RTC0=y` (add when using this conf for RTC stim).

- **`boards/nrf5340dk_nrf5340_cpuapp.overlay`**  
  - Already disables many unused **devicetree** nodes: I2C, SPI0/2/3/4, UART2/3, ADC, TIMER2, RTC0/1 (Zephyr driver), WDT1, COMP, PWM, PDM, I2S, QSPI, NFCT, QDEC, USBD, USBREG, VREGH.  
  - App uses **nrfx** for SPI1, TIMER0, and RTC0, so disabling `&rtc0` in DT only stops the Zephyr RTC driver; nrfx still uses the RTC0 hardware. No change needed there for RTC stim.

- **`boards/nrf5340dk_nrf5340_cpuapp.conf`**  
  - CryptoCell off (Oberon only), entropy not from HCI. Good for power.

---

## What Can Be Done Without Code Changes

These can be set in `prj_no_bt.conf` (or a merged fragment) to reduce power and compile time without touching source:

1. **RTC stim support**  
   - Add `CONFIG_NRFX_RTC0=y` so the RTC-driven stimulation build works when using `prj_no_bt.conf`.

2. **No console / no printk**  
   - `CONFIG_CONSOLE=n`  
   - `CONFIG_UART_CONSOLE=n`  
   - `CONFIG_PRINTK=n`  
   Reduces console traffic and related init; UART driver can stay enabled so existing UART references still link.

3. **No RTT**  
   - `CONFIG_USE_SEGGER_RTT=n`  
   Saves RTT-related code and any RTT-driven wakeups.

4. **Boot / banner**  
   - `CONFIG_BOOT_BANNER=n`  
   - `CONFIG_NCS_BOOT_BANNER=n`  
   Faster boot, less output.

5. **Assert (optional)**  
   - `CONFIG_ASSERT=n`  
   Saves a little code and removes assert checks; use only if you accept no runtime asserts.

6. **Flash map / layout (optional)**  
   - When BLE and settings are off, you can set `CONFIG_FLASH_MAP=n` and `CONFIG_FLASH_PAGE_LAYOUT=n` if nothing else in the no-BLE image uses them. Keep `CONFIG_FLASH=y` (kernel needs it).

7. **Heap / stacks**  
   - Reduce `CONFIG_HEAP_MEM_POOL_SIZE` and `CONFIG_SYSTEM_WORKQUEUE_STACK_SIZE` to what the no-BLE path actually needs; smaller heaps/stacks reduce RAM and can slightly reduce power.

8. **Size optimizations**  
   - `CONFIG_SIZE_OPTIMIZATIONS=y`  
   Reduces code size and can help power.

**Summary:** The above can all be applied in `prj_no_bt.conf` (or equivalent) to turn off unused features and minimize current consumption **without changing application code**.

---

## What Would Require Small Code Changes

To go further and actually **turn off** more peripherals (and their drivers), the build would need guards so that when a driver is disabled, the code does not reference it.

| Option | Effect | Code change needed |
|--------|--------|--------------------|
| **CONFIG_NRFX_TIMER1=n** | TIMER1 not used when BLE=n (only for MEASURE_TIMER) | In `timer.c`, guard `measurement_timer` and `measurement_timer_init()` with `#if defined(CONFIG_NRFX_TIMER1)` (or `CONFIG_BT` + MEASURE_TIMER) so they are not compiled when TIMER1 is disabled. |
| **CONFIG_SERIAL=n / CONFIG_NRFX_UARTE0=n** | UART fully off; no UART init or callbacks | In `main.c` and `BLE.c`: guard UART/console includes and all UART-related symbols (e.g. `uart_init`, `uart`, `uart_cb`, `configure_gpio`, `uart_async_adapter`) with `#if defined(CONFIG_BT)` or `#if defined(CONFIG_SERIAL)` so they are not built when UART is disabled. |
| **CONFIG_DK_LIBRARY=n** | No DK LEDs/buttons driver | Guard `#include <dk_buttons_and_leds.h>` and any use of `dk_*` / `RUN_STATUS_LED` etc. with `#if defined(CONFIG_DK_LIBRARY)` (or keep only in BLE path). |

Once those guards are in place, the corresponding Kconfig options can be set in `prj_no_bt.conf` to turn off those peripherals and further minimize current and compile time.

---

## Network Core and Sysbuild

From `docs/POWER_SAVING.md`:

- With **BLE off**, the app uses RTC+TIMER+SPI+GPIO only, but **sysbuild still builds and flashes the network core** (`ipc_radio`), which runs the BLE controller. That keeps the radio domain powered and increases static current.
- To **minimize current with BLE off**, you would either:
  - Flash only the app image (so the network core is not re-flashed), and/or  
  - Use a **minimal/blank network core** image (no BLE, no radio) and a sysbuild configuration that selects that image when building for “no BLE” power testing.

So “turning off all unused peripherals” for minimal power includes the **network core**: for the lowest current, the no-BLE build should use a minimal network core, not the full BLE controller. That is a sysbuild/board configuration change, not just `prj_no_bt.conf`.

---

## Recommended prj_no_bt.conf Additions (No Code Change)

Concrete additions to `prj_no_bt.conf` that turn off unused features and minimize current **without** changing code:

- Add RTC for current RTC stim build:  
  `CONFIG_NRFX_RTC0=y`
- Disable console/printk/RTT and boot output:  
  `CONFIG_CONSOLE=n`  
  `CONFIG_UART_CONSOLE=n`  
  `CONFIG_PRINTK=n`  
  `CONFIG_USE_SEGGER_RTT=n`  
  `CONFIG_BOOT_BANNER=n`  
  `CONFIG_NCS_BOOT_BANNER=n`
- Optional:  
  `CONFIG_ASSERT=n`  
  `CONFIG_FLASH_MAP=n`  
  `CONFIG_FLASH_PAGE_LAYOUT=n`  
  (only if no other part of the no-BLE image uses flash map/page layout)
- Optional: reduce heap and workqueue stack to what no-BLE needs.  
- Optional:  
  `CONFIG_SIZE_OPTIMIZATIONS=y`

With these, **yes**, the “prj_no_BLE” approach can be implemented to turn off unused peripherals and features and minimize current consumption, and the part that does **not** require code changes can be done entirely in `prj_no_bt.conf`. The rest (UART off, TIMER1 off, DK_LIBRARY off, minimal network core) can be done once you approve the corresponding small code and sysbuild changes.

## Flashing and Reflashing
To reflash a frozen network core, run:
nrfjprog --recover -f NRF53 --coprocessor CP_NETWORK
nrfjprog --recover -f NRF53 --coprocessor CP_APPLICATION
Then try flashing again