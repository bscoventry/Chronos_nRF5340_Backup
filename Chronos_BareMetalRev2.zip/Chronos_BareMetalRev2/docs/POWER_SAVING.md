# Power Saving on nRF5340

This document summarizes power-saving measures used in the project and optional steps for minimal static current.

## Already Applied (in tree)

| Area | What | Where |
|------|------|------|
| **Peripherals** | Unused app-core peripherals disabled (I2C, extra SPI/UART, ADC, RTC, PWM, USB, QSPI, NFC, etc.) | `boards/nrf5340dk_nrf5340_cpuapp.overlay` |
| **Crypto** | CryptoCell (CC312) off; software (Oberon) only | `boards/nrf5340dk_nrf5340_cpuapp.conf` |
| **Regulators** | VREGH explicitly disabled | Overlay `&vregh` |
| **Idle** | Default Zephyr idle (WFI) | — |

## Reverted (increased power on this design)

These were tried but **increased** power and are reverted or disabled:

| Area | Why reverted |
|------|----------------|
| **CONFIG_PM / CONFIG_PM_DEVICE** | Extra wakeups or suspend/resume overhead on this build. |
| **LFXO off + 32k RC** | Enabling 32k RC or changing LF clock increased current vs default. |
| **power_save_unused_pins()** | Driving unused pins low likely sinks current through board pull-ups or conflicts with shared pins (e.g. P0.0/P0.1). Call commented out in `main.c`. |

## Optional: Log and debug (lower power)

- **`prj_no_bt.conf`** already disables logging and reduces debug (CONFIG_LOG=n, CONFIG_DEBUG_THREAD_INFO=n) for minimal power when BLE is off.
- For **BLE on** but lower log/debug overhead, use **`prj_low_power.conf`** as a fragment:
  ```bash
  west build -b nrf5340dk/nrf5340 --sysbuild -- -DCONF_FILE="prj.conf;prj_low_power.conf"
  ```
- Disconnect or avoid using **SWD/debugger** when measuring current; leave SWD pins in a defined state if needed.

## Network core when BLE is off

When building with **`prj_no_bt.conf`** (Bluetooth off), the **application** core does not start BLE, but **sysbuild** still builds and flashes the **network core** image (`ipc_radio`), which runs the BLE controller. That keeps the radio domain (VREGRADIO, etc.) powered and increases static current.

To minimize static power with BLE off:

1. **Flash only the app**  
   After a no-BT build, flash only the application core image so the network core is not updated. The network core will keep running whatever was last flashed (e.g. full BLE controller), so this does **not** remove network-core current; it only avoids re-flashing it.

2. **Minimal / blank network core (advanced)**  
   For the lowest static current with BLE off, the network core should run a **minimal image** that does not start the BLE controller (e.g. idle loop only). That requires:
   - A separate sysbuild child image (e.g. a “blank” or “idle” network core), or
   - Using an NCS sample or configuration that provides such an image.

   The default sysbuild in this project does **not** provide a blank network core; `ipc_radio` is the BLE controller image. To add a true “no radio” option you would:
   - Add a new sysbuild image (e.g. `net_core_idle`) with a minimal `prj.conf` (no BLE, no radio), and
   - Use a sysbuild configuration that selects that image instead of `ipc_radio` when building for “BLE off” power testing.

3. **Summary**  
   For **BLE-on** operation, no change is needed. For **BLE-off** power testing, the biggest gain is from `prj_no_bt.conf` on the app; further reduction requires a minimal or blank network core image as above.

## Builds for power testing

- **Minimal power (BLE off + log off + reduced debug):**  
  `west build -b nrf5340dk/nrf5340 --sysbuild -- -DCONF_FILE=prj_no_bt.conf`
- **BLE on, lower log/debug overhead:**  
  `west build -b nrf5340dk/nrf5340 --sysbuild -- -DCONF_FILE="prj.conf;prj_low_power.conf"`

Add `-Dipc_radio_EXTRA_DTC_OVERLAY_FILE=boards/nrf5340dk_nrf5340_cpunet.overlay` if you use the network core overlay.
