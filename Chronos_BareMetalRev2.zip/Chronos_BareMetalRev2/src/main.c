/*
 * Copyright (c) 2018 Nordic Semiconductor ASA
 *
 * SPDX-License-Identifier: LicenseRef-Nordic-5-Clause
 */

/** @file
 *  @brief Nordic UART Bridge Service (NUS) sample
 */
#if defined(CONFIG_BT)
#include <uart_async_adapter.h>
#include <zephyr/drivers/uart.h>
#include <zephyr/usb/usb_device.h>
#endif

#include <zephyr/types.h>
#include <zephyr/kernel.h>
#include <zephyr/irq.h>
#include <zephyr/device.h>
#include <zephyr/devicetree.h>
#include <soc.h>

#if defined(CONFIG_BT)
#include <zephyr/bluetooth/bluetooth.h>
#include <zephyr/bluetooth/uuid.h>
#include <zephyr/bluetooth/gatt.h>
#include <zephyr/bluetooth/hci.h>
#include <bluetooth/services/nus.h>
#include <zephyr/settings/settings.h>
#include <dk_buttons_and_leds.h>
#endif

#include <stdio.h>
#include <string.h>

#include <zephyr/logging/log.h>

#include <nrfx_spim.h>
#include <nrfx_timer.h>
#include <nrfx_rtc.h>
#include <zephyr/sys/atomic.h>
#include <hal/nrf_gpio.h>

#include "BLE.h"

#if defined(CONFIG_SOC_NRF5340_CPUAPP)
/* nrf_gpio_pin_mcu_select can be undefined at link. Do MCUSEL locally.
 * nRF5340 PS: MCUSEL [17:16], 0=Network, 1=App, 2=TND. */
static void p1_pin_mcu_select_app(uint32_t p1_pin)
{
#if defined(NRF_P1)
	NRF_GPIO_Type *p1 = NRF_P1;
#else
	NRF_GPIO_Type *p1 = NRF_GPIO1;
#endif
	uint32_t cnf = p1->PIN_CNF[p1_pin] & ~(3u << 16);
	p1->PIN_CNF[p1_pin] = cnf | (1u << 16);
}
#endif

#include "spi.h"
#include "timer.h"
#include "rtc_stim.h"
#include "config.h"

LOG_MODULE_REGISTER(mymain, LOG_LEVEL_DBG);
static void init_clock();

#if defined(CONFIG_BT)
BT_CONN_CB_DEFINE(conn_callbacks) = {
	.connected        = connected,
	.disconnected     = disconnected,
	.recycled         = recycled_cb,
#ifdef CONFIG_BT_NUS_SECURITY_ENABLED
	.security_changed = security_changed,
#endif
};

static struct bt_nus_cb nus_cb = {
	.received = bt_receive_cb,
};
#endif /* CONFIG_BT */

static void init_misc_pins(void) {
    // Configure P0.16 as output (DAC1 CS)
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(0, 16));
    nrf_gpio_pin_set(NRF_GPIO_PIN_MAP(0, 16));  // Set high (inactive)
    
    // Configure P0.26 as output (DAC2 CS)
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(0, 26));
    nrf_gpio_pin_set(NRF_GPIO_PIN_MAP(0, 26));  // Set high (inactive)
    
    // Switch GPIOs (DAC1/2 → switch): all 0 at init
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(1, 3));
    nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(1, 3));
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(1, 0));
    nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(1, 0));
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(1, 1));
    nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(1, 1));
#if defined(CONFIG_SOC_NRF5340_CPUAPP)
    /* P1.00 and P1.01 are assigned to the network core by default. Reassign to
     * app core after cfg_output (cfg overwrites PIN_CNF; mcu_select must come last). */
    p1_pin_mcu_select_app(0);
    p1_pin_mcu_select_app(1);
#endif
    nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(0, 13));
    nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(0, 13));
}

#if defined(CONFIG_SOC_NRF5340_CPUAPP)
/* Power: set unused GPIOs to output low to avoid floating-pin leakage.
 * Used pins: P0.7, P0.13, P0.16, P0.23, P0.25, P0.26 (SPI/UART/DAC/switch),
 *            P1.0, P1.1, P1.2, P1.3 (switch, SPI SCK). P0.19/P0.21 = cpunet UART (leave alone).
 */
static const uint8_t used_p0[] = { 7, 13, 16, 19, 21, 23, 25, 26 };
static const uint8_t used_p1[] = { 0, 1, 2, 3 };
#define USED_P0_LEN (sizeof(used_p0) / sizeof(used_p0[0]))
#define USED_P1_LEN (sizeof(used_p1) / sizeof(used_p1[0]))

static bool pin_used_p0(uint8_t pin)
{
	for (size_t i = 0; i < USED_P0_LEN; i++) {
		if (used_p0[i] == pin) {
			return true;
		}
	}
	return false;
}

static bool pin_used_p1(uint8_t pin)
{
	for (size_t i = 0; i < USED_P1_LEN; i++) {
		if (used_p1[i] == pin) {
			return true;
		}
	}
	return false;
}

__attribute__((unused))
static void power_save_unused_pins(void)
{
	for (uint8_t p = 0; p < 32; p++) {
		if (!pin_used_p0(p)) {
			nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(0, p));
			nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(0, p));
		}
	}
	for (uint8_t p = 0; p < 16; p++) {
		if (!pin_used_p1(p)) {
			nrf_gpio_cfg_output(NRF_GPIO_PIN_MAP(1, p));
			nrf_gpio_pin_clear(NRF_GPIO_PIN_MAP(1, p));
		}
	}
}
#else
static void power_save_unused_pins(void) { (void)0; }
#endif

int main(void)
{
    #if defined(__ZEPHYR__)
        IRQ_CONNECT(NRFX_IRQ_NUMBER_GET(NRF_TIMER_INST_GET(TIMER_INST_IDX)), IRQ_PRIO_LOWEST,
                    NRFX_TIMER_INST_HANDLER_GET(TIMER_INST_IDX), 0, 0);
        IRQ_CONNECT(NRFX_IRQ_NUMBER_GET(NRF_SPIM_INST_GET(SPIM_INST_IDX)), IRQ_PRIO_LOWEST,
                    NRFX_SPIM_INST_HANDLER_GET(SPIM_INST_IDX), 0, 0);
#if !defined(CONFIG_BT)
        IRQ_CONNECT(NRFX_IRQ_NUMBER_GET(NRF_RTC_INST_GET(0)), IRQ_PRIO_LOWEST,
                    NRFX_RTC_INST_HANDLER_GET(0), 0, 0);
        irq_enable(NRFX_IRQ_NUMBER_GET(NRF_RTC_INST_GET(0)));
#endif
    #endif

    init_clock();
    init_misc_pins();
    spi_init();
    timer_init();
    update_pulse_width(CONFIG_PULSE_WIDTH_US);
    update_dac1_amplitude(CONFIG_STIM_AMPLITUDE);
    update_dac2_amplitude(CONFIG_STIM_AMPLITUDE);

#if defined(CONFIG_BT)
    update_stim_frequency(CONFIG_STIM_FREQUENCY_HZ);
    measurement_timer_init();
	int blink_status = 0;
	int err = 0;
    uint32_t experiment_counter = 0;

	configure_gpio();
	err = uart_init();
	if (err) {
		error();
	}
#endif

#if defined(CONFIG_BT)
	if (IS_ENABLED(CONFIG_BT_NUS_SECURITY_ENABLED)) {
		err = bt_conn_auth_cb_register(&conn_auth_callbacks);
		if (err) {
			LOG_ERR("Failed to register authorization callbacks. (err: %d)", err);
			return 0;
		}

		err = bt_conn_auth_info_cb_register(&conn_auth_info_callbacks);
		if (err) {
			LOG_ERR("Failed to register authorization info callbacks. (err: %d)", err);
			return 0;
		}
	}

	err = bt_enable(NULL);
	if (err) {
		error();
	}

	LOG_INF("Bluetooth initialized");

	k_sem_give(&ble_init_ok);

	if (IS_ENABLED(CONFIG_SETTINGS)) {
		settings_load();
	}

	err = bt_nus_init(&nus_cb);
	if (err) {
		LOG_ERR("Failed to initialize UART service (err: %d)", err);
		return 0;
	}

	k_work_init(&adv_work, adv_work_handler);
	advertising_start();
	for (;;) {
		dk_set_led(RUN_STATUS_LED, (++blink_status) % 2);
		k_msleep(10000);
		if (MEASURE_TIMER == 1) {
			experiment_counter += 10;
			error_data my_error_data;
			get_error_data(&my_error_data);
			printf("Counter: %i Elapsed: %is\nEvent0 running error: %lu avg error: %lu max error: %lu\nEvents1-3 running error: %lu avg error: %lu max error: %lu, %lu, %lu\n",
				my_error_data.mycounter,
				experiment_counter,
				my_error_data.event0_error,
				(my_error_data.event0_error / my_error_data.mycounter),
				my_error_data.event0_max,
				my_error_data.myerror,
				(my_error_data.myerror / my_error_data.mycounter),
				my_error_data.event1_max,
				my_error_data.event2_max,
				my_error_data.event3_max);
		}
	}
#else
	/* RTC low-power: no BLE; RTC wakes every stim period, timer runs one biphasic burst */
	rtc_stim_start_lfclk();
	rtc_stim_init(CONFIG_STIM_FREQUENCY_HZ);
	LOG_INF("RTC-driven stimulation at %u Hz (no BLE)", CONFIG_STIM_FREQUENCY_HZ);
	for (;;) {
		k_sleep(K_FOREVER);
	}
#endif /* CONFIG_BT */
}

K_THREAD_DEFINE(ble_write_thread_id, STACKSIZE, ble_write_thread, NULL, NULL,
		NULL, PRIORITY, 0, 0);

static void init_clock() {
	// select the clock source: HFINT (high frequency internal oscillator) or HFXO (external 32 MHz crystal)
	NRF_CLOCK_S->HFCLKSRC = (CLOCK_HFCLKSRC_SRC_HFINT << CLOCK_HFCLKSRC_SRC_Pos);

    // start the clock, and wait to verify that it is running
    NRF_CLOCK_S->TASKS_HFCLKSTART = 1;
    while (NRF_CLOCK_S->EVENTS_HFCLKSTARTED == 0);
    NRF_CLOCK_S->EVENTS_HFCLKSTARTED = 0;
}
